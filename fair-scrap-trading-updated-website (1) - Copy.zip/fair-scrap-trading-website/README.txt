Fair Scrap Trading website files

Files to upload to the root of your Cloudflare Pages project:
- index.html (main website)
- privacy-policy.html
- terms-and-conditions.html
- sitemap.xml
- robots.txt

The sitemap and canonical/social URLs are prepared for https://fairscraptrading.com/. They will work once you own and connect that domain. This package does not register the domain or deploy the site. Review the privacy policy and terms against your actual practices before publishing.
